<?php
/*
Template Name: Sobre mí

Descripcion: Esta plantilla se utiliza para mostrar la página Sobre mí.

*/
get_header();
?>
<main>
  
<div class="container__about-page">
  <h1>Sobre Mí</h1>
</div>

  <?php include_once get_template_directory() . '/components/about.php'; ?>

</main>
  
<?php

get_footer();
?>
