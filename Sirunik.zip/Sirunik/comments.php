<div class="comment-avatar">
  <?php echo get_avatar($comment, 64); // Muestra el avatar con un tamaño de 64 píxeles ?>
</div>

<?php if (get_comment_pages_count() > 1 && get_option('page_comments')) : ?>
<div class="comment-navigation">
  <div class="previous-comments">
    <?php previous_comments_link('Comentarios anteriores'); ?>
  </div>
  <div class="next-comments">
    <?php next_comments_link('Comentarios más recientes'); ?>
  </div>
</div>
<?php endif; ?>