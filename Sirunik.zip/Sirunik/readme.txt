# Nombre del tema

Este archivo contiene información sobre el tema.

## Descripción

Este tema es un tema personalizado para un sitio web de peluquería.

## Instalación

Para instalar este tema, sigue estos pasos:

1. Descarga el tema desde GitHub.
2. Descomprime el archivo zip en la carpeta `wp-content/themes` de tu sitio web.
3. Activa el tema desde el panel de administración de WordPress.

## Uso

Para usar este tema, sigue estos pasos:

1. Agrega el contenido de tu sitio web.
2. Personaliza el tema desde el panel de administración de WordPress.

## Autor

Este tema fue creado por Karlen Hakobyan.

## Licencia

Este tema está licenciado bajo la GPLv2.