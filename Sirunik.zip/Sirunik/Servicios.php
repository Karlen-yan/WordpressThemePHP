<?php
/*
Template Name: Servicios

Descripcion: Esta plantilla se utiliza para mostrar la página Servicios.

*/
get_header();
?>
<main class="container__servicios">
  <?php include_once get_template_directory() . '/components/exclusive-service.php'; ?>
  <div class="container__service">
    <div class="item__service">

      <div class="container__service-img">
        <div class="container__service-content">
          <h5>MASAJE CORPORAL</h5>
          <h1>45€</h1>
        </div>
        <img src="<?php echo esc_url( get_template_directory_uri() ); ?>./assets/img/___descarga.jpg" alt="img ejemplo">
      </div>
      <div class="container__service-img">
        <div class="container__service-content">
          <h5>CUIDADO DE UÑAS</h5>
          <h1>45€</h1>
        </div>
        <img src="<?php echo esc_url( get_template_directory_uri() ); ?>./assets/img/___French-Manicure.jpg" alt="img ejemplo">
      </div>
      <div class="container__service-img">
        <div class="container__service-content">
          
          <h5>PROTECCIÓN DE LA PIEL</h5>
          <h1>45€</h1>
        </div>
        <img src="<?php echo esc_url( get_template_directory_uri() ); ?>./assets/img/___masajefacial.jpg" alt="img ejemplo">
      </div>
      <div class="container__service-img">
        <div class="container__service-content">
          <h5>CUIDADO DE LA BELLEZA</h5>
          <h1>45€</h1>
      </div>
        <img src="<?php echo esc_url( get_template_directory_uri() ); ?>./assets/img/__service-skincare.jpg" alt="img ejemplo">
      </div>

    </div>
  </div>
</main>


<?php

get_footer();
?>