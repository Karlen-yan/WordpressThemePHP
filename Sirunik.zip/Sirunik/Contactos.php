<?php
/*
Template Name: Contactos

Descripcion: Esta plantilla se utiliza para mostrar la página Contactos.

*/
get_header();
?>
<main>
  <!-- <div class="container__contactos-title">
    <h1>Contácta me</h1>
  </div> -->

  <div class="container__contactos-title" style="background-image: url('<?php echo get_theme_mod('imagen_fondo_contacto', './assets/img/imagen_braids_twist.jpg'); ?>'); 
  background-repeat: no-repeat;
  background-size: cover;
  background-position: center;
  background-attachment: fixed;

  ">
        <h1><?php echo get_theme_mod('titulo_contacto', 'Contácta me'); ?></h1>
    </div>
  <div class="container__contacts" data-aos="fade-up"
     data-aos-duration="3000">
    <!-- <div class="datos"> -->
      <!-- <h2>Datos de la empresa</h2>
      <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. In euismod lectus nec eros laoreet, eu tincidunt quam semper. Morbi tristique quam orci, nec laoreet lorem scelerisque sit amet.</p>
      <p>
      <i class="fas fa-mobile-alt contacts__icons"></i>  555 555 5555</p>
      <p><i class="fas fa-envelope contacts__icons"></i> info@example.com</p>
      <p><i class="fas fa-map-marker-alt contacts__icons"></i> 
       Vía Favencia Barcelona, España         
    </p> -->
    <div class="datos">
    <h2><?php echo get_theme_mod('titulo_datos_empresa', 'Datos de la empresa'); ?></h2>

            <p><?php echo get_theme_mod('contenido_contacto_empresa', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. In euismod lectus nec eros laoreet, eu tincidunt quam semper. Morbi tristique quam orci, nec laoreet lorem scelerisque sit amet.'); ?></p>
            <p><i class="fas fa-mobile-alt contacts__icons"></i> <?php echo get_theme_mod('telefono_contacto', '555 555 5555'); ?></p>
            <p><i class="fas fa-envelope contacts__icons"></i> info@example.com</p>
            <p><i class="fas fa-map-marker-alt contacts__icons"></i> <?php echo get_theme_mod('direccion_contacto', 'Vía Favencia Barcelona, España'); ?></p>
        </div>
    <!-- </div> -->
    <div class="formulario">
      <h2>Formulario de contacto</h2>
      <form action="/contacto" method="POST">
        <input type="text" name="nombre" placeholder="Nombre">
        <input type="email" name="email" placeholder="Correo electrónico">
        <input type="text" name="asunto" placeholder="Asunto">
        <textarea name="mensaje" placeholder="Mensaje"></textarea>
        <input type="submit" value="Enviar">
      </form>
    </div>
  </div>
</main>
<?php

get_footer();
?>