// $(document).ready(function() {
//   $('.hamburger-button').click(function() {
//       $('.menu-ul').toggleClass('show-menu');
//   });
// });


// document.addEventListener("DOMContentLoaded", function () {
//   const carousel = document.querySelector(".carousel");
//   const carouselItems = document.querySelectorAll(".carousel-item");
//   let currentIndex = 0;

//   function showSlide(index) {
//       if (index < 0) {
//           currentIndex = carouselItems.length - 1;
//       } else if (index >= carouselItems.length) {
//           currentIndex = 0;
//       }

//       const offset = -currentIndex * 100;
//       carousel.style.transform = `translateX(${offset}%)`;
//   }

//   function nextSlide() {
//       currentIndex++;
//       showSlide(currentIndex);
//   }

//   function prevSlide() {
//       currentIndex--;
//       showSlide(currentIndex);
//   }

//   const nextButton = document.querySelector(".next-button");
//   const prevButton = document.querySelector(".prev-button");
// if (nextButton) {
//   nextButton.addEventListener("click", nextSlide);
//   showSlide(currentIndex);
// }

// if (prevButton) {
//   prevButton.addEventListener("click", prevSlide);
//   showSlide(currentIndex);
// }


//   // Auto-avance del carrusel (opcional)
//   // setInterval(nextSlide, 5000); // Cambia el valor 5000 para ajustar la velocidad de cambio automático
// });


// // servicios exclusivos
// const serviciosData = {
//   braids_twist: {
//     imagen: 'imagen_braids_twist.jpg',
//     title:"BRAIDS & TWIST",
//     price:"$25.00 Per Head",
//     contenido: 'Lorem ipsum dolor, sit amet consectetur adipisicing elit. Veniam magnam tempora recusandae a expedita adipisci atque aperiam fuga ipsum quis, quisquam explicabo consequatur fugit facere? Aperiam quo architecto sint? Possimus.'
//   },
//   hair_color: {
//     imagen: 'imagen_hair_color.jpg',
//     title:"HAIR COLOR",
//     price:"$40.00 Per Head",
//     contenido: 'Lorem ipsum dolor, sit amet consectetur adipisicing elit. Veniam magnam tempora recusandae a expedita adipisci atque aperiam fuga ipsum quis, quisquam explicabo consequatur fugit facere? Aperiam quo architecto sint? Possimus.Lorem ipsum dolor, sit amet consectetur adipisicing elit. Veniam magnam tempora recusandae a expedita adipisci atque aperiam fuga ipsum quis, quisquam explicabo consequatur fugit facere? Aperiam quo architecto sint? Possimus.'
//   },
//   hair_extension: {
//     imagen: 'imagen_hair_extension.jpg',
//     title:"HAIR EXTENSION ",
//     price:"$19.00 Per Head",
//     contenido: 'Lorem ipsum dolor, sit amet consectetur adipisicing elit. Veniam magnam tempora recusandae a expedita adipisci atque aperiam fuga ipsum quis, quisquam explicabo consequatur fugit facere? Aperiam quo architecto sint? Possimus.Lorem ipsum dolor, sit amet consectetur adipisicing elit. Veniam magnam tempora recusandae a expedita adipisci atque aperiam fuga ipsum quis, quisquam explicabo consequatur fugit facere? Aperiam quo architecto sint? Possimus.'
//   },
//   corrective_color: {
//     imagen: 'imagen_corrective_color.jpg',
//     title:"CORRECTIVE COLOR",
//     price:"$13.00 Per Head",
//     contenido: 'Lorem ipsum dolor, sit amet consectetur adipisicing elit. Veniam magnam tempora recusandae a expedita adipisci atque aperiam fuga ipsum quis, quisquam explicabo consequatur fugit facere? Aperiam quo architecto sint? Possimus.'
//   },
//   hair_cut: {
//     imagen: 'imagen_hair_cut.jpg',
//     title:"HAIR CUT",
//     price:"$48.00 Per Head",
//     contenido: 'Lorem ipsum dolor, sit amet consectetur adipisicing elit. Veniam magnam tempora recusandae a expedita adipisci atque aperiam fuga ipsum quis, quisquam explicabo consequatur fugit facere? Aperiam quo architecto sint? Possimus.Lorem ipsum dolor, sit amet consectetur adipisicing elit. Veniam magnam tempora recusandae a expedita adipisci atque aperiam fuga ipsum quis, quisquam explicabo consequatur fugit facere? Aperiam quo architecto sint? Possimus.'
//   },
//   partial_foil: {
//     imagen: 'imagen_partial_foil.jpg',
//     title:"PARTIAL FOIL",
//     price:"$10.00 Per Head",
//     contenido: 'Lorem ipsum dolor, sit amet consectetur adipisicing elit. Veniam magnam tempora recusandae a expedita adipisci atque aperiam fuga ipsum quis, quisquam explicabo consequatur fugit facere? Aperiam quo architecto sint? Possimus.'
//   },
//   extension_per_track: {
//     imagen: 'imagen_extension_per_track.jpg',
//     title:"EXTENSION PER TRACK",
//     price:"$40.00 Per Head",
//     contenido: 'Lorem ipsum dolor, sit amet consectetur adipisicing elit. Veniam magnam tempora recusandae a expedita adipisci atque aperiam fuga ipsum quis, quisquam explicabo consequatur fugit facere? Aperiam quo architecto sint? Possimus.Lorem ipsum dolor, sit amet consectetur adipisicing elit. Veniam magnam tempora recusandae a expedita adipisci atque aperiam fuga ipsum quis, quisquam explicabo consequatur fugit facere? Aperiam quo architecto sint? Possimus.'
//   },
// };

// function getImageUrl(servicio) {
//   const idImagen = serviciosData[servicio].imagen;
//   return`/manicura/wp-content/themes/Sirunik/assets/img/${idImagen}`;
// }

// const listaServicios = document.querySelectorAll('.servicios li');
// const imagenSeleccionada = document.querySelector('.imagen-seleccionada img');
// const titleSeleccionado = document.querySelector('.imagen-seleccionada h1');
// const priceSeleccionado = document.querySelector('.imagen-seleccionada h5');
// const contenidoSeleccionado = document.querySelector('.imagen-seleccionada p');

// if (listaServicios && listaServicios.length > 0) {
//   listaServicios.forEach((servicio) => {
//     servicio.addEventListener('click', () => {
//       const servicioSeleccionado = servicio.getAttribute('data-servicio');
      
//       const servicioData = serviciosData[servicioSeleccionado];
//       const imagenUrl = getImageUrl(servicioSeleccionado);
  
//       imagenSeleccionada.src = imagenUrl;
//       titleSeleccionado.textContent = servicioData.title;
//       priceSeleccionado.textContent = servicioData.price;
//       contenidoSeleccionado.textContent = servicioData.contenido;
  
//       const servicioAnterior = document.querySelector('.selected');
  
//       if (servicioAnterior) {
//         servicioAnterior.classList.remove('selected');
//       }
//       servicio.classList.add('selected');
      
//     });
//   });
//   listaServicios[0].click();
// }  


// const carousel = document.querySelector(".work__with-carousel-inner");
// const prevButton = document.querySelector(".work__with-carousel-prev");
// const nextButton = document.querySelector(".work__with-carousel-next");

// let currentImage = 0;
// if(prevButton){
//   prevButton.addEventListener("click", function() {
//       currentImage--;
//       if (currentImage < 0) {
//           currentImage = 7;
//       }
  
//       const translateValue = currentImage * -(100 / 4);
//       carousel.style.transform = `translateX(${translateValue}%)`;
//   });

// }
// if(nextButton){
//   nextButton.addEventListener("click", function() {
//       currentImage++;
//       if (currentImage > 7) {
//           currentImage = 0;
//       }
  
//       const translateValue = currentImage * -(100 / 4);
//       carousel.style.transform = `translateX(${translateValue}%)`;
//   });
// }

// // menu hamburgesa 
// const hamburgerButton = document.getElementById('hamburger');
// const menuUl = document.querySelector('.menu-ul');
// const section = document.querySelectorAll("section");
//   hamburgerButton.addEventListener('click', () => {
//     menuUl.classList.toggle('active'); // Mostrar u ocultar el menú
//     hamburgerButton.classList.toggle('active'); // Cambiar el botón a "X"
    
//     if (hamburgerButton.classList.contains('active')) {
//       menuUl.style.right = "-60%"; // Botón "X", mostrar el  menú
//  // Botón "X", mostrar el menú
//  section.style.opacity = "0.60";
//     } else {
//       menuUl.style.right = "-200%"; // Botón hamburguesa, ocultar el menú
//     }
  
//   });
//   // Cerrar el menú cuando se hace clic fuera de él
//   document.addEventListener('click', (e) => {
//     if (!menuUl.contains(e.target) && !hamburgerButton.contains(e.target)) {
//       menuUl.classList.remove('active');
//       hamburgerButton.classList.remove('active');
//       menuUl.style.right = "-200%"; 
//     }
//   });



// // Boton subir 
// const button = document.querySelector(".btn-top");

// if (button) {
//   button.addEventListener("click", () => {
//     window.scrollTo(0, 0);
//   });
// }
