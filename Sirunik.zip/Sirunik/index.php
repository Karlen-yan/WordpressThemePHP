<?php get_header(); ?>

<main>
  <section class="carousel-container">
    <div  class="carousel">
      <div id="carrusel1" class="carousel-item">
      <img src="<?php echo esc_url(get_theme_mod('imagen_carrusel_1', get_template_directory_uri() . '/assets/img/CuidaManos.png')); ?>" alt="Imagen 1">

      </div>
      <div id="carrusel2" class="carousel-item">
      <img src="<?php echo esc_url(get_theme_mod('imagen_carrusel_2', get_template_directory_uri() . '/assets/img/PedirCita.png')); ?>" alt="Imagen 1">
      </div>
      <div id="carrusel" class="carousel-item">
      <img src="<?php echo esc_url(get_theme_mod('imagen_carrusel_3', get_template_directory_uri() . '/assets/img/salonUnias.png')); ?>" alt="Imagen 1">
      </div>
    </div>
    <button class="prev-button">
      < </button>
        <button class="next-button">></button>
  </section>

  <?php include_once get_template_directory() . '/components/about.php'; ?>
  <?php include_once get_template_directory() . '/components/exclusive-service.php'; ?>


  
 
      <section 
       class="work__with-carousel-controls"  
       data-aos="fade-up"
       data-aos-duration="3000">
        <div class="work__with-carousel">
          <button class="work__with-carousel-prev"><</button>
            <div class="work__with-carousel-inner">

                <div class="work__with-carousel-item">
                    <img src="<?php echo esc_url( get_template_directory_uri() ); ?>./assets/img/brand-1-2-1.png" alt="Imagen 1">
                </div>
                <div class="work__with-carousel-item">
                    <img src="<?php echo esc_url( get_template_directory_uri() ); ?>./assets/img/brand-2-2-1.png" alt="Imagen 2">
                </div>
                <div class="work__with-carousel-item">
                    <img src="<?php echo esc_url( get_template_directory_uri() ); ?>./assets/img/brand-4-2-1.png" alt="Imagen 3">
                </div>
                <div class="work__with-carousel-item">
                    <img src="<?php echo esc_url( get_template_directory_uri() ); ?>./assets/img/brand-2-2-1.png" alt="Imagen 4">
                </div>
                <div class="work__with-carousel-item">
                    <img src="<?php echo esc_url( get_template_directory_uri() ); ?>./assets/img/brand-1-2-1.png" alt="Imagen 5">
                </div>
                <div class="work__with-carousel-item">
                    <img src="<?php echo esc_url( get_template_directory_uri() ); ?>./assets/img/brand-2-2-1.png" alt="Imagen 6">
                </div>
                <div class="work__with-carousel-item">
                    <img src="<?php echo esc_url( get_template_directory_uri() ); ?>./assets/img/brand-4-2-1.png" alt="Imagen 7">
                </div>
                <div class="work__with-carousel-item">
                    <img src="<?php echo esc_url( get_template_directory_uri() ); ?>./assets/img/brand-1-2-1.png" alt="Imagen 8">
                </div>
                <div class="work__with-carousel-item">
                    <img src="<?php echo esc_url( get_template_directory_uri() ); ?>./assets/img/brand-2-2-1.png" alt="Imagen 8">
                </div>
                <div class="work__with-carousel-item">
                    <img src="<?php echo esc_url( get_template_directory_uri() ); ?>./assets/img/brand-4-2-1.png" alt="Imagen 8">
                </div>
                <div class="work__with-carousel-item">
                    <img src="<?php echo esc_url( get_template_directory_uri() ); ?>./assets/img/brand-2-2-1.png" alt="Imagen 8">
                </div>
            </div>
            <button class="work__with-carousel-next">></button>
        </div>
</section>
  



</main>

<?php get_footer(); ?>