<div class="barra-lateral-derecha">
  <?php dynamic_sidebar('sidebar-right'); ?>
</div>
