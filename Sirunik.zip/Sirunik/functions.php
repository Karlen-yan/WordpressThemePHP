
<?php
// include wp-includes.php
require_once(ABSPATH . 'wp-config.php');
require_once(ABSPATH . 'wp-includes/functions.php');

// title 
add_theme_support('title-tag');


if (function_exists('register_nav_menus')) {
  register_nav_menus(array('menu-principal' => 'Menú principal'));
}

add_filter('nav_menu_link_attributes', function ($atts, $item, $args) {
  $atts['class'] .= 'menu-item-link';
  return $atts;
}, 10, 3);

// wp_head()
add_action('wp_head', 'sirunik_head');

function sirunik_head()
{
  wp_enqueue_style("style", get_stylesheet_uri());
}

// wp_footer()
add_action('wp_footer', 'sirunik_footer');

function sirunik_footer()
{
  // include './footer.php';
  wp_enqueue_script("script", get_template_directory_uri() . "/script.js");
}

// wp_link_pages()
add_action('wp_link_pages', 'sirunik_link_pages');

load_theme_textdomain('sirunik', get_template_directory() . '/languages');

function sirunik_link_pages()
{
  $args = array(
    'before' => '<ul class="pagination">',
    'after' => '</ul>',
    'link_before' => '<li>',
    'link_after' => '</li>',
    'active_class' => 'active',
  );

  wp_link_pages($args);
}


add_filter('post_class', 'sirunik_post_class');

function sirunik_post_class($classes)
{
  if (is_single()) {
    $classes[] = 'post-single';
  }
  return $classes;
}

function load_jquery()
{
  wp_enqueue_script('jquery');
}
add_action('wp_enqueue_scripts', 'load_jquery');

// add_theme_support( 'automatic-feed-links' )
add_theme_support('automatic-feed-links');

add_theme_support("title-tag");

// Agrega la función wp_body_open()
add_action("wp_body_open", "wp_body_open");

function my_theme_wp_body_open()
{
  do_action('wp_body_open');
}
add_action('wp_body_open', 'my_theme_wp_body_open');

// fonts google 
function enqueue_google_fonts()
{
  wp_enqueue_style('google-fonts', 'https://fonts.googleapis.com/css?family=Montserrat:400,700&display=swap');
}
add_action('wp_enqueue_scripts', 'enqueue_google_fonts');

// iconos 
function enqueue_font_awesome()
{
  wp_enqueue_style('font-awesome', 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css');
}
add_action('wp_enqueue_scripts', 'enqueue_font_awesome');

// comments 
add_theme_support('post-thumbnails');
add_theme_support('align-wide');

//  soporte for avatares
add_theme_support('post-thumbnails');

//  soporte for pagination
function custom_pagination()
{
  global $wp_query;

  $big = 999999999;
  $pages = paginate_links(array(
    'base' => str_replace($big, '%#%', esc_url(get_pagenum_link($big))),
    'format' => '?paged=%#%',
    'current' => max(1, get_query_var('paged')),
    'total' => $wp_query->max_num_pages,
    'prev_text' => __('&laquo; Anterior', 'Sirunik'), 
    'next_text' => __('Siguiente &raquo;', 'Sirunik'), 
  ));

  if ($pages) {
    echo '<div class="pagination">';
    echo $pages;
    echo '</div>';
  }
}

function my_theme_widgets_init() {
  register_sidebar(array(
      'name' => __('Sidebar Principal', 'Sirunik'),
      'id' => 'sidebar-1',
      'description' => __('Área de widgets en la barra lateral', 'Sirunik'),
      'before_widget' => '<aside id="%1$s" class="widget %2$s">',
      'after_widget' => '</aside>',
      'before_title' => '<h2 class="widget-title">',
      'after_title' => '</h2>',
  ));
}

add_action('widgets_init', 'my_theme_widgets_init');
// Agregar soporte para avatares estándar de WordPress
add_theme_support('post-thumbnails');

// Establecer el tamaño del avatar (ajusta los valores según sea necesario)
set_post_thumbnail_size(96, 96, true);

add_theme_support('editor-styles');
add_editor_style('editor-style.css');

// Soporte bloques 
add_theme_support('wp-block-styles');
add_theme_support('align-wide');



// personalizar 

function agregar_personalizador($wp_customize) {

  
  // Agregar una sección al Personalizador logo
  $wp_customize->add_section('seccion_personalizada-logo', array(
      'title' => 'Logo',
      'priority' => 30,
  ));
     // Agregar una opción para subir un logo
     $wp_customize->add_setting('logo_imagen');

     $wp_customize->add_control(new WP_Customize_Image_Control($wp_customize, 'logo_imagen', array(
         'label' => 'Subir Logo',
         'section' => 'seccion_personalizada-logo',
     )));
  
     
  // Agregar una sección al Personalizador carusel 
  $wp_customize->add_section('seccion_personalizada', array(
      'title' => 'Carusel ínicio',
      'priority' => 30,
  ));

  $wp_customize->add_setting('imagen_carrusel_1');

  $wp_customize->add_control(new WP_Customize_Image_Control($wp_customize, 'imagen_carrusel_1', array(
      'label' => 'Imagen 1 del Carrusel 1',
      'section' => 'seccion_personalizada',
  )));

  // Opción para la segunda imagen del carrusel
  $wp_customize->add_setting('imagen_carrusel_2');

  $wp_customize->add_control(new WP_Customize_Image_Control($wp_customize, 'imagen_carrusel_2', array(
    'label' => 'Imagen 2 del Carrusel 1',
    'section' => 'seccion_personalizada',
  )));
  
  // Opción para la tercera imagen del carrusel
  $wp_customize->add_setting('imagen_carrusel_3');
  
  $wp_customize->add_control(new WP_Customize_Image_Control($wp_customize, 'imagen_carrusel_3', array(
      'label' => 'Imagen 3 del Carrusel 1',
      'section' => 'seccion_personalizada',
  )));


  set_theme_mod('imagen_carrusel_1', get_template_directory_uri() . '/assets/img/CuidaManos.png');
  set_theme_mod('imagen_carrusel_2', get_template_directory_uri() . '/assets/img/PedirCita.png');
  set_theme_mod('imagen_carrusel_3', get_template_directory_uri() . '/assets/img/salonUnias.png');
  
  
  
  
  // contacto superior
    // Agregar una sección al Personalizador para la información de contacto
    $wp_customize->add_section('seccion_personalizada-contacto', array(
      'title' => 'Información de Contacto (Superior)',
      'priority' => 30,
  ));

  // Agregar opciones para la dirección de correo electrónico y el número de teléfono
  $wp_customize->add_setting('direccion_correo', array(
      'default' => 'mail@gmail.com',
      'sanitize_callback' => 'sanitize_text_field',
  ));

  $wp_customize->add_control('direccion_correo', array(
      'label' => 'Dirección de Correo Electrónico',
      'section' => 'seccion_personalizada-contacto',
      'type' => 'text',
  ));

  $wp_customize->add_setting('numero_telefono', array(
      'default' => '+34 63255221',
      'sanitize_callback' => 'sanitize_text_field',
  ));

  $wp_customize->add_control('numero_telefono', array(
      'label' => 'Número de Teléfono',
      'section' => 'seccion_personalizada-contacto',
      'type' => 'text',
  ));



}

add_action('customize_register', 'agregar_personalizador');




// Sobre mi 
function agregar_personalizador_sobre_mi($wp_customize) {
  // Agregar una sección al Personalizador para "Sobre mí"
  $wp_customize->add_section('seccion_personalizada_sobre_mi', array(
      'title' => 'Sobre Mí',
      'priority' => 30,
  ));

  // Agregar opción para la imagen de "Sobre mí"
  $wp_customize->add_setting('imagen_sobre_mi', array(
      'sanitize_callback' => 'esc_url_raw',
  ));

  $wp_customize->add_control(new WP_Customize_Image_Control($wp_customize, 'imagen_sobre_mi', array(
      'label' => 'Imagen de "Sobre mí"',
      'section' => 'seccion_personalizada_sobre_mi',
  )));
  set_theme_mod('imagen_sobre_mi', get_template_directory_uri() . '/assets/img/Sobremi.jpg');

  // Agregar opción para el encabezado de "Sobre mí"
  $wp_customize->add_setting('encabezado_sobre_mi', array(
      'default' => 'Anna Minasyan Hakobyan',
      'sanitize_callback' => 'sanitize_text_field',
  ));

  $wp_customize->add_control('encabezado_sobre_mi', array(
      'label' => 'Encabezado de "Sobre mí"',
      'section' => 'seccion_personalizada_sobre_mi',
      'type' => 'text',
  ));

  // Agregar opción para el contenido de "Sobre mí"
  $wp_customize->add_setting('contenido_sobre_mi', array(
      'default' => 'Lorem ipsum dolor, sit amet consectetur adipisicing elit. Saepe a, temporibus rem animi magnam explicabo ab quo quas? Nihil velit vel nemo laboriosam corporis consequatur dolor inventore libero sed placeat!</p>
      <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Saepe a, temporibus rem animi magnam explicabo ab quo quas? Nihil velit vel nemo laboriosam corporis consequatur dolor inventore libero sed placeat!, Lorem ipsum dolor, sit amet consectetur adipisicing elit. Saepe a, temporibus rem animi magnam explicabo ab quo quas? Nihil velit vel nemo laboriosam corporis consequatur dolor inventore libero sed placeat!',
      'sanitize_callback' => 'wp_kses_post',
  ));

  $wp_customize->add_control('contenido_sobre_mi', array(
      'label' => 'Contenido de "Sobre mí"',
      'section' => 'seccion_personalizada_sobre_mi',
      'type' => 'textarea',
  ));
}

add_action('customize_register', 'agregar_personalizador_sobre_mi');


// contacto  
function agregar_personalizador_contacto($wp_customize) {
  // Agregar una sección al Personalizador para "Contáctame"
  $wp_customize->add_section('seccion_personalizada_contacto', array(
      'title' => 'Contáctame',
      'priority' => 34, // Elije la prioridad adecuada
  ));

  // Agregar opción para el título de la sección
  $wp_customize->add_setting('titulo_contacto', array(
      'default' => 'Contácta me',
      'sanitize_callback' => 'sanitize_text_field',
  ));

  $wp_customize->add_control('titulo_contacto', array(
      'label' => 'Título de la sección',
      'section' => 'seccion_personalizada_contacto',
      'type' => 'text',
  ));


   // Agregar opción para la imagen de fondo
   $wp_customize->add_setting('imagen_fondo_contacto', array(
    'default' => '',
    'sanitize_callback' => 'esc_url_raw',
));

$wp_customize->add_control(new WP_Customize_Image_Control($wp_customize, 'imagen_fondo_contacto', array(
    'label' => 'Imagen de fondo de Contáctame',
    'section' => 'seccion_personalizada_contacto',
)));



// Agregar opción para el título "Datos de la empresa"
$wp_customize->add_setting('titulo_datos_empresa', array(
    'default' => 'Datos de la empresa',
    'sanitize_callback' => 'sanitize_text_field',
));

$wp_customize->add_control('titulo_datos_empresa', array(
    'label' => 'Título de Datos de la empresa',
    'section' => 'seccion_personalizada_contacto',
    'type' => 'text',
));
  // Agregar opción para el contenido de datos de la empresa
  $wp_customize->add_setting('contenido_contacto_empresa', array(
      'default' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. In euismod lectus nec eros laoreet, eu tincidunt quam semper. Morbi tristique quam orci, nec laoreet lorem scelerisque sit amet.',
      'sanitize_callback' => 'wp_kses_post',
  ));

  $wp_customize->add_control('contenido_contacto_empresa', array(
      'label' => 'Contenido de datos de la empresa',
      'section' => 'seccion_personalizada_contacto',
      'type' => 'textarea',
  ));

  // Agregar opción para el número de teléfono de contacto
  $wp_customize->add_setting('telefono_contacto', array(
      'default' => '555 555 5555',
      'sanitize_callback' => 'sanitize_text_field',
  ));

  $wp_customize->add_control('telefono_contacto', array(
      'label' => 'Número de teléfono de contacto',
      'section' => 'seccion_personalizada_contacto',
      'type' => 'text',
  ));

  // Agregar opción para la dirección de la empresa
  $wp_customize->add_setting('direccion_contacto', array(
      'default' => 'Vía Favencia Barcelona, España',
      'sanitize_callback' => 'sanitize_text_field',
  ));

  $wp_customize->add_control('direccion_contacto', array(
      'label' => 'Dirección de la empresa',
      'section' => 'seccion_personalizada_contacto',
      'type' => 'text',
  ));
}

add_action('customize_register', 'agregar_personalizador_contacto');






// Footer 
function agregar_personalizador_footer($wp_customize) {
  // Agregar una sección al Personalizador para el footer
  $wp_customize->add_section('seccion_personalizada_footer', array(
      'title' => 'Texto del Footer',
      'priority' => 32, // Elije la prioridad adecuada
  ));

  // Agregar opción para el texto del footer
  $wp_customize->add_setting('texto_footer', array(
      'default' => 'Lorem, ipsum dolor sit amet consectetur adipisicing elit. Eum, qui ullam ad, earum ipsum perferendis minima ipsam necessitatibus, est alias sapiente? Explicabo soluta commodi alias minus ad debitis, nobis expedita.',
      'sanitize_callback' => 'wp_kses_post', // Permite contenido HTML limitado
  ));

  $wp_customize->add_control('texto_footer', array(
      'label' => 'Texto del Footer',
      'section' => 'seccion_personalizada_footer',
      'type' => 'textarea',
  ));
}

add_action('customize_register', 'agregar_personalizador_footer');

function agregar_personalizador_galeria_footer($wp_customize) {
  // Agregar una sección al Personalizador para la galería de imágenes del footer
  $wp_customize->add_section('seccion_personalizada_galeria_footer', array(
      'title' => 'Galería de Imágenes del Footer',
      'priority' => 33, // Elije la prioridad adecuada
  ));

  // Agregar opciones para las imágenes de la galería
  for ($i = 1; $i <= 6; $i++) {
      $wp_customize->add_setting("imagen_galeria_footer_$i", array(
          'default' => './assets/img/brand-1-2-1.png', // Deja esto en blanco por defecto o define una imagen por defecto
          'sanitize_callback' => 'esc_url_raw',
      ));

      $wp_customize->add_control(new WP_Customize_Image_Control($wp_customize, "imagen_galeria_footer_$i", array(
          'label' => "Imagen $i",
          'section' => 'seccion_personalizada_galeria_footer',
      )));
  }
}

add_action('customize_register', 'agregar_personalizador_galeria_footer');