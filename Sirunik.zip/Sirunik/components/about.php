
<section 
     class="container__about"
     data-aos="fade-up"
     data-aos-duration="3000">
    <div class="container__about-item container__about-image">
        <img src="<?php echo esc_url(get_theme_mod('imagen_sobre_mi', '/assets/img/Sobremi.jpg')); ?>" alt="Imagen de Trabajador">
    </div>
    <div class="container__about-item container__about-content">
        <h1><?php echo esc_html(get_theme_mod('encabezado_sobre_mi', 'Anna Minasyan Hakobyan')); ?></h1>
        <p><?php echo wp_kses_post(get_theme_mod('contenido_sobre_mi', 'Lorem ipsum dolor, sit amet consectetur adipisicing elit. Saepe a, temporibus rem animi magnam explicabo ab quo quas? Nihil velit vel nemo laboriosam corporis consequatur dolor inventore libero sed placeat!, Lorem ipsum dolor, sit amet consectetur adipisicing elit. Saepe a, temporibus rem animi magnam explicabo ab quo quas? Nihil velit vel nemo laboriosam corporis consequatur dolor inventore libero sed placeat!')); ?></p>
    </div>
</section>

<!-- <section class="container__about">
    <div class="container__about-item container__about-image">
        <img src="https://www.sabervivirtv.com/medio/2023/07/26/riesgos-manicura-y-pedicura_5ee99488_230726081209_1280x720.jpg" alt="Tu Imagen">
    </div>
    <div class="container__about-item container__about-content">
        <h1>Anna Minasyan Hakobyan</h1>
        <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Saepe a, temporibus rem animi magnam explicabo ab quo quas? Nihil velit vel nemo laboriosam corporis consequatur dolor inventore libero sed placeat!</p>
        <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Saepe a, temporibus rem animi magnam explicabo ab quo quas? Nihil velit vel nemo laboriosam corporis consequatur dolor inventore libero sed placeat!, Lorem ipsum dolor, sit amet consectetur adipisicing elit. Saepe a, temporibus rem animi magnam explicabo ab quo quas? Nihil velit vel nemo laboriosam corporis consequatur dolor inventore libero sed placeat!</p>
    </div>
</section> -->