<section 
   class="exclusive-service"
   data-aos="fade-up"
   data-aos-duration="3000"
   >
    <h1>Descubrir</h1>
    <p>SERVICIOS EXCLUSIVOS</p>
    <div class="continer__exclusive-service">
      <div class="item__exclusive-list">
        <div class="servicios">
          <ul>
            <li data-servicio="braids_twist">
              <div>BRAIDS & TWIST <span>$25</span></div>
            </li>
            <li data-servicio="hair_color">
              <div>HAIR COLOR <span>$40</span></div>
            </li>
            <li data-servicio="hair_extension">
              <div>HAIR EXTENSION <span>$19</span></div>
            </li>
            <li data-servicio="corrective_color">
              <div>CORRECTIVE COLOR <span>$13</span></div>
            </li>
            <li data-servicio="hair_cut">
              <div>HAIR CUT <span>$48</span></div>
            </li>
            <li data-servicio="partial_foil">
              <div>PARTIAL FOIL <span>$10</span></div>
            </li>
            <li data-servicio="extension_per_track">
              <div>EXTENSION PER TRACK <span>$40</span></div>
            </li>
          </ul>
        </div>
      </div>
      <div class="item__exclusive-service">
        <div class="imagen-seleccionada">
          <img src="" alt="" />
          <h1></h1>
          <h5></h5>
          <p></p>
        </div>
      </div>
    </div>
  </section>