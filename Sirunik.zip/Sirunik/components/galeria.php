<section class="container__galeria">

  <div class="content__galeria">
  <div class="gallery">
    <div class="gallery-item">
      <a href="https://www.reiteman.com/wp-content/uploads/2021/04/reforma_piso70-scaled-1-1024x682.jpg" data-lightbox="gridImage">
      <img src="https://www.reiteman.com/wp-content/uploads/2021/04/reforma_piso70-scaled-1-1024x682.jpg" alt="Imagen 1"></a>
      
    </div>
    <div class="gallery-item">
      <a href="https://www.reiteman.com/wp-content/uploads/2021/04/reforma_piso70-scaled-1-1024x682.jpg" data-lightbox="gridImage">
      <img   src="https://www.reiteman.com/wp-content/uploads/2021/04/reforma_piso70-scaled-1-1024x682.jpg" alt="Imagen 2">
      </a>
      
    </div>
    <div class="gallery-item">
      <a href="https://www.reiteman.com/wp-content/uploads/2021/04/reforma_piso70-scaled-1-1024x682.jpg" data-lightbox="gridImage">
      <img src="https://www.reiteman.com/wp-content/uploads/2021/04/reforma_piso70-scaled-1-1024x682.jpg" alt="Imagen 3"></a>
      
    </div>
    <div class="gallery-item">
      <a href="https://www.reiteman.com/wp-content/uploads/2021/04/reforma_piso70-scaled-1-1024x682.jpg" data-lightbox="gridImage">
      <img src="https://www.reiteman.com/wp-content/uploads/2021/04/reforma_piso70-scaled-1-1024x682.jpg" alt="Imagen 1"></a>
      
    </div>
    <div class="gallery-item">
      <a href="https://www.reiteman.com/wp-content/uploads/2021/04/reforma_piso70-scaled-1-1024x682.jpg" data-lightbox="gridImage">
      <img   src="https://www.reiteman.com/wp-content/uploads/2021/04/reforma_piso70-scaled-1-1024x682.jpg" alt="Imagen 2">
      </a>
    </div>
    <div class="gallery-item">
      <a href="https://www.reiteman.com/wp-content/uploads/2021/04/reforma_piso70-scaled-1-1024x682.jpg" data-lightbox="gridImage">
      <img src="https://www.reiteman.com/wp-content/uploads/2021/04/reforma_piso70-scaled-1-1024x682.jpg" alt="Imagen 3"></a>
      
    </div>
    <div class="gallery-item">
      <a href="https://www.reiteman.com/wp-content/uploads/2021/04/reforma_piso70-scaled-1-1024x682.jpg" data-lightbox="gridImage">
      <img src="https://www.reiteman.com/wp-content/uploads/2021/04/reforma_piso70-scaled-1-1024x682.jpg" alt="Imagen 1"></a>
      
    </div>
    <div class="gallery-item">
      <a href="https://www.reiteman.com/wp-content/uploads/2021/04/reforma_piso70-scaled-1-1024x682.jpg" data-lightbox="gridImage">
      <img   src="https://www.reiteman.com/wp-content/uploads/2021/04/reforma_piso70-scaled-1-1024x682.jpg" alt="Imagen 2">
      </a>
    </div>
    <div class="gallery-item">
      <a href="https://www.reiteman.com/wp-content/uploads/2021/04/reforma_piso70-scaled-1-1024x682.jpg" data-lightbox="gridImage">
      <img src="https://www.reiteman.com/wp-content/uploads/2021/04/reforma_piso70-scaled-1-1024x682.jpg" alt="Imagen 3"></a>
      
    </div>
  </div>
  </div>
</section>